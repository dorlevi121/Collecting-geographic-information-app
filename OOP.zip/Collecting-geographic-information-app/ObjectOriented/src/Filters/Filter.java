package Filters;
import Wifi.WiFi;

public interface Filter{
	public boolean isBelong(WiFi wifi);
}
